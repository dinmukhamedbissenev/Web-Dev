export interface IDescriptive{
    id: number,
    name: string,
    description: string
}